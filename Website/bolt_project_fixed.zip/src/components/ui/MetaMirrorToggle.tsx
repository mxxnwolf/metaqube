import React from 'react';
import { motion } from 'framer-motion';
import { useAppStore } from '../../store/useAppStore';

const MetaMirrorToggle: React.FC = () => {
  const { metaMirrorMode, toggleMetaMirrorMode } = useAppStore();
  
  const handleToggle = () => {
    // Play glitch sound effect if available
    // const audio = new Audio('/sounds/glitch.mp3');
    // audio.play();
    
    toggleMetaMirrorMode();
  };
  
  return (
    <motion.button
      className={`flex items-center space-x-2 px-4 py-2 rounded-lg transition-all ${
        metaMirrorMode 
          ? 'bg-metaEmerald-500 text-deepCosmos-900' 
          : 'bg-deepCosmos-700 text-quantumGrey-300 hover:bg-deepCosmos-600'
      }`}
      onClick={handleToggle}
      whileHover={{ scale: 1.05 }}
      whileTap={{ scale: 0.95 }}
    >
      <span className="font-medium">
        {metaMirrorMode ? 'Exit MetaMirror' : 'Enter MetaMirror'}
      </span>
      <svg 
        xmlns="http://www.w3.org/2000/svg" 
        width="20" 
        height="20" 
        viewBox="0 0 24 24" 
        fill="none" 
        stroke="currentColor" 
        strokeWidth="2" 
        strokeLinecap="round" 
        strokeLinejoin="round"
      >
        <path d="M2 12h5"></path>
        <path d="M17 12h5"></path>
        <path d="M9 6v12"></path>
        <path d="M15 6v12"></path>
      </svg>
    </motion.button>
  );
};

export default MetaMirrorToggle;