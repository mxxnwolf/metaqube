import React, { useRef, useEffect } from 'react';
import { motion } from 'framer-motion';
import { useMousePosition } from '../../hooks/useMousePosition';
import { useDeviceOrientation } from '../../hooks/useDeviceOrientation';
import { useWindowSize } from 'react-use';

const HeroCube: React.FC = () => {
  const cubeRef = useRef<HTMLDivElement>(null);
  const mousePosition = useMousePosition();
  const deviceOrientation = useDeviceOrientation();
  const { width, height } = useWindowSize();
  
  useEffect(() => {
    if (!cubeRef.current) return;
    
    let rotateX = 0;
    let rotateY = 0;
    let baseRotation = 0;
    
    const animate = () => {
      if (!cubeRef.current) return;
      
      baseRotation += 0.5;
      
      // Use device orientation on mobile
      if (width < 768 && deviceOrientation.beta !== null && deviceOrientation.gamma !== null) {
        rotateX = deviceOrientation.beta * 0.5;
        rotateY = deviceOrientation.gamma * 0.5;
      } 
      // Use mouse position on desktop
      else if (mousePosition.x !== null && mousePosition.y !== null) {
        const mouseXPercentage = (mousePosition.x / width) * 2 - 1;
        const mouseYPercentage = (mousePosition.y / height) * 2 - 1;
        rotateX = mouseYPercentage * 15;
        rotateY = mouseXPercentage * 15;
      }
      
      cubeRef.current.style.transform = `rotateX(${rotateX}deg) rotateY(${rotateY + baseRotation}deg) rotateZ(0deg)`;
      requestAnimationFrame(animate);
    };
    
    const animationFrame = requestAnimationFrame(animate);
    
    return () => {
      cancelAnimationFrame(animationFrame);
    };
  }, [mousePosition, deviceOrientation, width, height]);
  
  const handleTap = () => {
    if (!cubeRef.current) return;
    
    // Add a quick spin animation on tap
    cubeRef.current.style.transition = 'transform 1s cubic-bezier(0.175, 0.885, 0.32, 1.275)';
    cubeRef.current.style.transform = 'rotateX(360deg) rotateY(360deg) rotateZ(0deg)';
    
    setTimeout(() => {
      if (cubeRef.current) {
        cubeRef.current.style.transition = 'transform 0.1s ease-out';
      }
    }, 1000);
  };
  
  return (
    <div className="relative flex items-center justify-center w-full h-80 sm:h-96">
      {/* Enhanced animated grid background */}
      <div className="absolute inset-0 grid grid-cols-8 grid-rows-8 opacity-20">
        {Array.from({ length: 64 }).map((_, i) => (
          <div 
            key={i} 
            className="border border-metaEmerald-500/30 transition-colors duration-300"
            style={{
              transitionDelay: `${i * 10}ms`,
            }}
          />
        ))}
      </div>
      
      {/* Enhanced glow effect behind cube */}
      <motion.div 
        className="absolute w-48 h-48 bg-metaEmerald-500/30 rounded-full blur-2xl"
        animate={{ 
          scale: [1, 1.4, 1],
          opacity: [0.5, 0.9, 0.5]
        }}
        transition={{ duration: 4, repeat: Infinity }}
      />
      
      {/* Additional ambient glow */}
      <motion.div
        className="absolute w-64 h-64 rounded-full"
        style={{
          background: 'radial-gradient(circle, rgba(26, 209, 181, 0.3) 0%, rgba(26, 209, 181, 0) 70%)',
        }}
        animate={{
          scale: [1, 1.2, 1],
          opacity: [0.3, 0.6, 0.3],
        }}
        transition={{ duration: 3, repeat: Infinity }}
      />
      
      {/* Cube wrapper */}
      <div 
        className="cube-wrapper w-48 h-48 perspective-500 cursor-pointer"
        onClick={handleTap}  
      >
        <div 
          ref={cubeRef}
          className="cube relative w-full h-full transform-style-3d transition-transform duration-100 ease-out"
          style={{ transformStyle: 'preserve-3d' }}
        >
          {/* Cube faces */}
          {['front', 'back', 'right', 'left', 'top', 'bottom'].map((face, index) => (
            <div
              key={face}
              className={`absolute w-full h-full border-2 border-metaEmerald-500 flex items-center justify-center bg-metaEmerald-500/10 backdrop-blur-sm
                ${face === 'front' ? 'transform translate-z-100px' : ''}
                ${face === 'back' ? 'transform translate-z-neg-100px rotate-y-180deg' : ''}
                ${face === 'right' ? 'transform translate-x-100px rotate-y-90deg' : ''}
                ${face === 'left' ? 'transform translate-x-neg-100px rotate-y-neg-90deg' : ''}
                ${face === 'top' ? 'transform translate-y-neg-100px rotate-x-90deg' : ''}
                ${face === 'bottom' ? 'transform translate-y-100px rotate-x-neg-90deg' : ''}
              `}
              style={{
                backfaceVisibility: 'hidden',
                transformStyle: 'preserve-3d',
                ...(face === 'front' && { transform: 'translateZ(100px)' }),
                ...(face === 'back' && { transform: 'rotateY(180deg) translateZ(100px)' }),
                ...(face === 'right' && { transform: 'rotateY(90deg) translateZ(100px)' }),
                ...(face === 'left' && { transform: 'rotateY(-90deg) translateZ(100px)' }),
                ...(face === 'top' && { transform: 'rotateX(90deg) translateZ(100px)' }),
                ...(face === 'bottom' && { transform: 'rotateX(-90deg) translateZ(100px)' }),
              }}
            >
              {/* Enhanced inner wireframe lines with glow */}
              <div className="absolute w-full h-full">
                <div className="absolute top-1/3 w-full h-px bg-metaEmerald-500 opacity-70 shadow-glow"></div>
                <div className="absolute top-2/3 w-full h-px bg-metaEmerald-500 opacity-70 shadow-glow"></div>
                <div className="absolute left-1/3 h-full w-px bg-metaEmerald-500 opacity-70 shadow-glow"></div>
                <div className="absolute left-2/3 h-full w-px bg-metaEmerald-500 opacity-70 shadow-glow"></div>
              </div>
              
              {/* Corner highlights */}
              <div className="absolute inset-0">
                <div className="absolute top-0 left-0 w-2 h-2 bg-metaEmerald-500 rounded-full blur-sm"></div>
                <div className="absolute top-0 right-0 w-2 h-2 bg-metaEmerald-500 rounded-full blur-sm"></div>
                <div className="absolute bottom-0 left-0 w-2 h-2 bg-metaEmerald-500 rounded-full blur-sm"></div>
                <div className="absolute bottom-0 right-0 w-2 h-2 bg-metaEmerald-500 rounded-full blur-sm"></div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default HeroCube;