import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Cuboid as Cube } from 'lucide-react';
import MetaMirrorToggle from '../ui/MetaMirrorToggle';
import { useAppStore } from '../../store/useAppStore';

const Navbar: React.FC = () => {
  const [scrolled, setScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const { metaMirrorMode } = useAppStore();
  
  useEffect(() => {
    const handleScroll = () => {
      const isScrolled = window.scrollY > 10;
      if (isScrolled !== scrolled) {
        setScrolled(isScrolled);
      }
    };
    
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, [scrolled]);
  
  const navLinks = [
    { name: 'Home', href: '#' },
    { name: 'Services', href: '#services' },
    { name: 'Build', href: '#build-qube' },
    { name: 'Frens', href: '#frens' },
    { name: 'Contact', href: '#contact' }
  ];
  
  return (
    <motion.nav
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 py-4 ${
        scrolled || mobileMenuOpen 
          ? metaMirrorMode 
            ? 'bg-deepCosmos-800 bg-opacity-95 border-b border-metaEmerald-500/30'
            : 'bg-quantumGrey-50 bg-opacity-95 border-b border-quantumGrey-200' 
          : 'bg-transparent'
      }`}
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      transition={{ duration: 0.5 }}
    >
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center">
          <motion.a 
            href="#" 
            className="flex items-center space-x-2 text-2xl font-bold"
            whileHover={{ scale: 1.05 }}
          >
            <Cube className="text-metaEmerald-500" size={32} />
            <span className={metaMirrorMode ? 'text-prismWhite' : 'text-deepCosmos-900'}>METAQUBE</span>
          </motion.a>
          
          {/* Desktop menu */}
          <div className="hidden md:flex items-center space-x-8">
            <div className="flex space-x-6">
              {navLinks.map((link) => (
                <motion.a
                  key={link.name}
                  href={link.href}
                  className={`font-medium hover:text-metaEmerald-500 transition-colors ${
                    metaMirrorMode ? 'text-prismWhite' : 'text-deepCosmos-900'
                  }`}
                  whileHover={{ scale: 1.1 }}
                >
                  {link.name}
                </motion.a>
              ))}
            </div>
            
            <MetaMirrorToggle />
          </div>
          
          {/* Mobile menu toggle */}
          <div className="md:hidden">
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className={`p-2 rounded-lg ${metaMirrorMode ? 'text-prismWhite' : 'text-deepCosmos-900'}`}
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="24"
                height="24"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                {mobileMenuOpen ? (
                  <path d="M18 6L6 18M6 6l12 12" />
                ) : (
                  <path d="M4 8h16M4 16h16" />
                )}
              </svg>
            </button>
          </div>
        </div>
      </div>
      
      {/* Mobile menu */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div
            className={`md:hidden absolute w-full ${
              metaMirrorMode ? 'bg-deepCosmos-800' : 'bg-quantumGrey-50'
            }`}
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.3 }}
          >
            <div className="container mx-auto px-4 py-4">
              <div className="flex flex-col space-y-4">
                {navLinks.map((link) => (
                  <a
                    key={link.name}
                    href={link.href}
                    className={`font-medium py-2 px-4 rounded-lg hover:bg-opacity-10 ${
                      metaMirrorMode 
                        ? 'text-prismWhite hover:bg-metaEmerald-500' 
                        : 'text-deepCosmos-900 hover:bg-deepCosmos-900'
                    }`}
                    onClick={() => setMobileMenuOpen(false)}
                  >
                    {link.name}
                  </a>
                ))}
                
                <div className="pt-2">
                  <MetaMirrorToggle />
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.nav>
  );
};

export default Navbar;