import React, { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import HeroCube from '../3d/HeroCube';
import { useAppStore } from '../../store/useAppStore';

const ctaMessages = [
  { id: 0, text: "Need a Qube that slaps?" },
  { id: 1, text: "Brand's mid? Let's fix that." },
  { id: 2, text: "Web3's boring. You aren't." },
  { id: 3, text: "Meta without the verse." },
  { id: 4, text: "Craft digital experiences that matter." },
  { id: 5, text: "Build beyond boundaries." },
  { id: 6, text: "Accelerate your digital transformation." },
];

const Hero: React.FC = () => {
  const { metaMirrorMode, currentCTA, nextCTA } = useAppStore();
  
  useEffect(() => {
    const interval = setInterval(() => {
      nextCTA();
    }, 4000);
    
    return () => clearInterval(interval);
  }, [nextCTA]);
  
  return (
    <section 
      className={`relative min-h-screen flex flex-col items-center justify-center pt-20 pb-10 overflow-hidden transition-colors duration-500 ${
        metaMirrorMode ? 'bg-deepCosmos-900' : 'bg-prismWhite'
      }`}
    >
      {/* Background elements */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-full grid grid-cols-12 grid-rows-12 opacity-20">
          {Array.from({ length: 144 }).map((_, i) => (
            <div key={i} className="border border-metaEmerald-500/10" />
          ))}
        </div>
      </div>
      
      <div className="container mx-auto px-4 z-10 flex flex-col items-center">
        <motion.div
          className="text-center mb-8"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
        >
          <motion.h1 
            className={`text-4xl md:text-6xl font-bold mb-4 ${
              metaMirrorMode ? 'text-prismWhite' : 'text-deepCosmos-900'
            }`}
          >
            <span>METAQUBE</span>
          </motion.h1>
          <motion.p 
            className={`text-xl md:text-2xl max-w-2xl mx-auto ${
              metaMirrorMode ? 'text-quantumGrey-300' : 'text-deepCosmos-600'
            }`}
          >
            Transcending traditional spaces and accelerate next-generation digital experiences.
          </motion.p>
        </motion.div>
        
        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="mb-12"
        >
          <HeroCube />
        </motion.div>
        
        <motion.div
          className="flex flex-col items-center space-y-6"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.4 }}
        >
          <motion.div 
            className="h-12 flex items-center justify-center"
            key={currentCTA}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.5 }}
          >
            <p className={`text-xl font-medium ${
              metaMirrorMode ? 'text-metaEmerald-400' : 'text-metaEmerald-600'
            }`}>
              {ctaMessages[currentCTA].text}
            </p>
          </motion.div>
          
          <motion.a
            href="#build-qube"
            className="bg-metaEmerald-500 text-deepCosmos-900 px-8 py-4 rounded-lg text-xl font-bold hover:bg-metaEmerald-400 transition-colors"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            Build Your Qube
          </motion.a>
        </motion.div>
      </div>
    </section>
  );
};

export default Hero;