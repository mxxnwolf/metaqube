import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { useAppStore } from './store/useAppStore';
import Navbar from './components/layout/Navbar';
import Footer from './components/sections/Footer';
import HomePage from './pages/HomePage';
import AboutPage from './pages/AboutPage';
import ServicesPage from './pages/ServicesPage';
import CaseStudiesPage from './pages/CaseStudiesPage';
import CareerPage from './pages/CareerPage';
import BlogPage from './pages/BlogPage';
import PrivacyPage from './pages/PrivacyPage';
import TermsPage from './pages/TermsPage';
import ContactPage from './pages/ContactPage';

function App() {
  const { darkMode, metaMirrorMode, setDarkMode } = useAppStore();
  
  React.useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [darkMode]);
  
  React.useEffect(() => {
    if (metaMirrorMode) {
      setDarkMode(true);
      document.body.classList.add('animate-glitch');
      setTimeout(() => {
        document.body.classList.remove('animate-glitch');
      }, 500);
    }
  }, [metaMirrorMode, setDarkMode]);
  
  return (
    <Router>
      <div className={`transition-colors duration-300 ${
        metaMirrorMode ? 'bg-deepCosmos-900 text-prismWhite' : 'bg-prismWhite text-deepCosmos-900'
      }`}>
        <Navbar />
        
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/about" element={<AboutPage />} />
          <Route path="/services" element={<ServicesPage />} />
          <Route path="/case-studies" element={<CaseStudiesPage />} />
          <Route path="/careers" element={<CareerPage />} />
          <Route path="/blog" element={<BlogPage />} />
          <Route path="/privacy" element={<PrivacyPage />} />
          <Route path="/terms" element={<TermsPage />} />
          <Route path="/contact" element={<ContactPage />} />
        </Routes>
        
        <Footer />
      </div>
    </Router>
  );
}

export default App;