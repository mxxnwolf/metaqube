import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useAppStore } from '../../store/useAppStore';

const ToggleGroup: React.FC = () => {
  const { toggleOptions, updateToggleOption } = useAppStore();
  const [message, setMessage] = useState<string>('');
  const [showTooltip, setShowTooltip] = useState(false);
  
  useEffect(() => {
    const fast = toggleOptions.find(o => o.id === 'fast')?.active || false;
    const cheap = toggleOptions.find(o => o.id === 'cheap')?.active || false;
    const good = toggleOptions.find(o => o.id === 'good')?.active || false;
    
    if (fast && cheap && !good) {
      setMessage("It's gonna break.");
    } else if (cheap && good && !fast) {
      setMessage("See you next year.");
    } else if (fast && good && !cheap) {
      setMessage("You're payin' for it.");
    } else {
      setMessage('');
    }
  }, [toggleOptions]);

  const handleInfoClick = () => {
    setShowTooltip(!showTooltip);
  };
  
  return (
    <div className="relative">
      <div className="flex items-center justify-center mb-2">
        <h2 className="text-2xl font-bold">Project Parameters</h2>
        <button 
          onClick={handleInfoClick}
          className="ml-2 text-quantumGrey-500 hover:text-metaEmerald-500 transition-colors"
        >
          <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <circle cx="12" cy="12" r="10"></circle>
            <path d="M12 16v-4"></path>
            <path d="M12 8h.01"></path>
          </svg>
        </button>
        <AnimatePresence>
          {showTooltip && (
            <motion.div 
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="absolute -top-12 left-1/2 transform -translate-x-1/2 bg-deepCosmos-700 text-prismWhite p-2 rounded shadow-lg z-10 w-64"
            >
              Choose 2 parameters max. The 3rd parameter will auto-disable.
            </motion.div>
          )}
        </AnimatePresence>
      </div>
      
      <div className="flex space-x-4 justify-center">
        {toggleOptions.map((option) => (
          <motion.button
            key={option.id}
            onClick={() => updateToggleOption(option.id, !option.active)}
            className={`relative px-6 py-3 rounded-lg text-lg font-semibold transition-all 
              ${option.active 
                ? 'bg-metaEmerald-500 text-deepCosmos-900 shadow-lg' 
                : 'bg-deepCosmos-600 text-quantumGrey-300 hover:bg-deepCosmos-500'}`}
            whileTap={{ scale: 0.95 }}
            layout
          >
            {option.active && (
              <motion.div
                className="absolute inset-0 rounded-lg"
                initial={{ opacity: 0 }}
                animate={{ 
                  opacity: [0.2, 0.5, 0.2], 
                  boxShadow: [
                    '0 0 0 0 rgba(26, 209, 181, 0)', 
                    '0 0 20px 10px rgba(26, 209, 181, 0.3)', 
                    '0 0 0 0 rgba(26, 209, 181, 0)'
                  ] 
                }}
                transition={{ duration: 2, repeat: Infinity }}
              />
            )}
            {option.label}
          </motion.button>
        ))}
      </div>
      
      <AnimatePresence>
        {message && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 10 }}
            className="text-center mt-4 text-metaEmerald-300 font-medium italic"
          >
            {message}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default ToggleGroup;