import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useAppStore } from '../../store/useAppStore';

const BuildYourQube: React.FC = () => {
  const { qubeOptions, selectQubeOption, resetQubeOptions, assembling, setAssembling } = useAppStore();
  const [email, setEmail] = useState('');
  const [submitted, setSubmitted] = useState(false);
  
  const selectedCount = qubeOptions.filter(option => option.selected).length;
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (selectedCount === 0) return;
    
    setSubmitted(true);
    
    // Reset form after submission
    setTimeout(() => {
      setEmail('');
      resetQubeOptions();
      setSubmitted(false);
    }, 3000);
  };
  
  const startAssembly = () => {
    if (selectedCount === 0) return;
    setAssembling(true);
    
    // Reset assembly animation after it completes
    setTimeout(() => {
      setAssembling(false);
    }, 2000);
  };
  
  return (
    <section id="build-qube" className="py-24 bg-deepCosmos-900 relative overflow-hidden">
      {/* Background grid */}
      <div className="absolute inset-0 grid grid-cols-12 grid-rows-12 opacity-10">
        {Array.from({ length: 144 }).map((_, i) => (
          <div key={i} className="border border-metaEmerald-500/10" />
        ))}
      </div>
      
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold mb-4 text-prismWhite">
            Build Your Own <span className="text-metaEmerald-500">Qube</span>
          </h2>
          <p className="text-quantumGrey-300 text-lg max-w-2xl mx-auto">
            Select the use cases that match your needs, and we'll craft a custom solution that transcends traditional spaces.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto mb-12">
          {qubeOptions.map((option) => (
            <motion.div
              key={option.id}
              className={`p-6 border-2 rounded-lg cursor-pointer transition-all hover-card
                ${option.selected 
                  ? 'border-metaEmerald-500 bg-metaEmerald-500/10' 
                  : 'border-deepCosmos-600 bg-deepCosmos-800 hover:border-metaEmerald-800'}`}
              onClick={() => selectQubeOption(option.id)}
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
            >
              <h3 className="text-xl font-bold mb-2 text-prismWhite">{option.label}</h3>
              <p className="text-quantumGrey-300">{option.description}</p>
              
              {option.selected && (
                <motion.div 
                  className="mt-4 flex justify-end"
                  initial={{ opacity: 0, scale: 0 }}
                  animate={{ opacity: 1, scale: 1 }}
                >
                  <div className="w-6 h-6 rounded-full bg-metaEmerald-500 flex items-center justify-center">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" className="text-deepCosmos-900">
                      <polyline points="20 6 9 17 4 12"></polyline>
                    </svg>
                  </div>
                </motion.div>
              )}
            </motion.div>
          ))}
        </div>
        
        <div className="flex flex-col items-center justify-center">
          <motion.button
            className={`btn-meta px-8 py-4 rounded-lg text-xl font-bold mb-8 transition-all
              ${selectedCount > 0 
                ? 'bg-metaEmerald-500 text-deepCosmos-900 hover:bg-metaEmerald-400' 
                : 'bg-deepCosmos-700 text-quantumGrey-500 cursor-not-allowed'}`}
            disabled={selectedCount === 0}
            onClick={startAssembly}
            whileHover={selectedCount > 0 ? { scale: 1.05 } : {}}
            whileTap={selectedCount > 0 ? { scale: 0.95 } : {}}
          >
            {assembling ? 'Assembling...' : 'Assemble Your Qube'}
          </motion.button>
          
          <AnimatePresence>
            {assembling && (
              <motion.div 
                className="relative w-48 h-48 mb-8"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
              >
                <motion.div 
                  className="absolute inset-0 border-2 border-metaEmerald-500"
                  initial={{ scale: 0, rotate: 0 }}
                  animate={{ 
                    scale: [0, 1, 1], 
                    rotate: [0, 180, 360],
                    borderRadius: ["50%", "0%"],
                  }}
                  transition={{ duration: 1.5 }}
                />
                
                {selectedCount > 0 && (
                  <motion.div 
                    className="absolute inset-0 flex items-center justify-center text-metaEmerald-500 font-bold text-2xl"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: [0, 1, 0.8] }}
                    transition={{ delay: 1, duration: 1 }}
                  >
                    QUBE BUILT
                  </motion.div>
                )}
              </motion.div>
            )}
          </AnimatePresence>
          
          <AnimatePresence>
            {(assembling || selectedCount > 0) && (
              <motion.form
                className="w-full max-w-md mx-auto bg-deepCosmos-800 p-8 rounded-lg border border-deepCosmos-600"
                onSubmit={handleSubmit}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: 20 }}
                transition={{ delay: assembling ? 1.5 : 0 }}
              >
                <h3 className="text-2xl font-bold mb-4 text-prismWhite">Ready to Build?</h3>
                <p className="text-quantumGrey-300 mb-6">Drop your email and let's make this real.</p>
                
                <div className="mb-4">
                  <input
                    type="email"
                    placeholder="Your email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                    className="w-full bg-deepCosmos-700 border border-deepCosmos-600 text-prismWhite p-3 rounded-lg focus:outline-none focus:ring-2 focus:ring-metaEmerald-500"
                  />
                </div>
                
                <button
                  type="submit"
                  className="w-full bg-metaEmerald-500 text-deepCosmos-900 font-bold py-3 px-4 rounded-lg hover:bg-metaEmerald-400 transition-colors btn-meta"
                >
                  {submitted ? 'Submitted!' : 'Get Started'}
                </button>
              </motion.form>
            )}
          </AnimatePresence>
        </div>
      </div>
    </section>
  );
};

export default BuildYourQube;