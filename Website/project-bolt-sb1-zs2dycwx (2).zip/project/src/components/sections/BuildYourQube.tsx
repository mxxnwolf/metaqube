import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import * as Dialog from '@radix-ui/react-dialog';
import { X } from 'lucide-react';
import { useAppStore } from '../../store/useAppStore';

const BuildYourQube: React.FC = () => {
  const { qubeOptions, selectQubeOption, resetQubeOptions, assembling, setAssembling } = useAppStore();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    country: '',
    description: ''
  });
  const [submitted, setSubmitted] = useState(false);
  
  const selectedCount = qubeOptions.filter(option => option.selected).length;
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
    
    setTimeout(() => {
      setDialogOpen(false);
      setFormData({
        name: '',
        email: '',
        country: '',
        description: ''
      });
      resetQubeOptions();
      setSubmitted(false);
    }, 2000);
  };
  
  const startAssembly = () => {
    if (selectedCount === 0) return;
    setAssembling(true);
    
    setTimeout(() => {
      setAssembling(false);
      setDialogOpen(true);
    }, 2000);
  };
  
  return (
    <section id="build-qube" className="py-24 bg-deepCosmos-900 relative overflow-hidden">
      {/* Animated background effects */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {/* Glowing orbs */}
        {Array.from({ length: 3 }).map((_, i) => (
          <motion.div
            key={`orb-${i}`}
            className="absolute w-96 h-96 rounded-full"
            style={{
              background: `radial-gradient(circle, rgba(26, 209, 181, 0.15) 0%, rgba(26, 209, 181, 0) 70%)`,
              left: `${25 + i * 25}%`,
              top: `${20 + i * 30}%`,
            }}
            animate={{
              scale: [1, 1.2, 1],
              opacity: [0.3, 0.6, 0.3],
            }}
            transition={{
              duration: 8,
              repeat: Infinity,
              delay: i * 2,
              ease: "easeInOut"
            }}
          />
        ))}
        
        {/* Grid overlay */}
        <div className="absolute inset-0 grid grid-cols-12 grid-rows-12 opacity-10">
          {Array.from({ length: 144 }).map((_, i) => (
            <div key={i} className="border border-metaEmerald-500/10" />
          ))}
        </div>
      </div>
      
      <div className="container mx-auto px-4 relative z-10">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold mb-4 text-prismWhite">
            Build Your Own <span className="text-metaEmerald-500">Qube</span>
          </h2>
          <p className="text-quantumGrey-300 text-lg max-w-2xl mx-auto">
            Select the use cases that match your needs, and we'll craft a custom solution that transcends traditional spaces.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto mb-12">
          {qubeOptions.map((option) => (
            <motion.button
              key={option.id}
              className={`p-6 border-2 rounded-lg cursor-pointer transition-all group relative overflow-hidden
                ${option.selected 
                  ? 'border-metaEmerald-500 bg-metaEmerald-500/10' 
                  : 'border-deepCosmos-600 bg-deepCosmos-800 hover:border-metaEmerald-800'}`}
              onClick={() => selectQubeOption(option.id)}
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
            >
              {/* Hover glow effect */}
              <motion.div
                className="absolute inset-0 bg-metaEmerald-500 opacity-0 group-hover:opacity-10 transition-opacity duration-300"
                initial={false}
                animate={{ scale: option.selected ? 1 : 0.8 }}
              />
              
              {/* Content */}
              <div className="relative z-10">
                <h3 className="text-xl font-bold mb-2 text-prismWhite text-left">{option.label}</h3>
                <p className="text-quantumGrey-300 text-left">{option.description}</p>
                
                {option.selected && (
                  <motion.div 
                    className="mt-4 flex justify-end"
                    initial={{ opacity: 0, scale: 0 }}
                    animate={{ opacity: 1, scale: 1 }}
                  >
                    <div className="w-6 h-6 rounded-full bg-metaEmerald-500 flex items-center justify-center">
                      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" className="text-deepCosmos-900">
                        <polyline points="20 6 9 17 4 12"></polyline>
                      </svg>
                    </div>
                  </motion.div>
                )}
              </div>
              
              {/* Selection indicator */}
              {option.selected && (
                <motion.div
                  className="absolute inset-0 border-2 border-metaEmerald-500 rounded-lg"
                  layoutId="selection"
                  transition={{ type: "spring", bounce: 0.2, duration: 0.6 }}
                />
              )}
            </motion.button>
          ))}
        </div>
        
        <div className="flex flex-col items-center justify-center relative z-20">
          <motion.button
            className={`btn-meta px-8 py-4 rounded-lg text-xl font-bold mb-8 transition-all relative overflow-hidden
              ${selectedCount > 0 
                ? 'bg-metaEmerald-500 text-deepCosmos-900 hover:bg-metaEmerald-400' 
                : 'bg-deepCosmos-700 text-quantumGrey-500 cursor-not-allowed'}`}
            disabled={selectedCount === 0}
            onClick={startAssembly}
            whileHover={selectedCount > 0 ? { scale: 1.05 } : {}}
            whileTap={selectedCount > 0 ? { scale: 0.95 } : {}}
          >
            {/* Button glow effect */}
            {selectedCount > 0 && (
              <motion.div
                className="absolute inset-0 bg-white opacity-0 hover:opacity-20 transition-opacity duration-300"
                initial={false}
                animate={{ scale: assembling ? 1.2 : 1 }}
              />
            )}
            <span className="relative z-10">
              {assembling ? 'Assembling...' : 'Assemble Your Qube'}
            </span>
          </motion.button>
          
          <AnimatePresence>
            {assembling && (
              <motion.div 
                className="relative w-48 h-48 mb-8"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
              >
                <motion.div 
                  className="absolute inset-0 border-2 border-metaEmerald-500"
                  initial={{ scale: 0, rotate: 0 }}
                  animate={{ 
                    scale: [0, 1, 1], 
                    rotate: [0, 180, 360],
                    borderRadius: ["50%", "0%"],
                  }}
                  transition={{ duration: 1.5 }}
                />
                
                {/* Glow effect */}
                <motion.div
                  className="absolute inset-0 bg-metaEmerald-500 rounded-full filter blur-xl"
                  initial={{ opacity: 0, scale: 0.5 }}
                  animate={{
                    opacity: [0, 0.2, 0],
                    scale: [0.5, 1.5, 0.5],
                  }}
                  transition={{ duration: 2, repeat: Infinity }}
                />
                
                {selectedCount > 0 && (
                  <motion.div 
                    className="absolute inset-0 flex items-center justify-center text-metaEmerald-500 font-bold text-2xl"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: [0, 1, 0.8] }}
                    transition={{ delay: 1, duration: 1 }}
                  >
                    QUBE BUILT
                  </motion.div>
                )}
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>

      <Dialog.Root open={dialogOpen} onOpenChange={setDialogOpen}>
        <Dialog.Portal>
          <Dialog.Overlay className="fixed inset-0 bg-black/50 backdrop-blur-sm z-[100]" />
          <Dialog.Content className="fixed top-[50%] left-[50%] -translate-x-[50%] -translate-y-[50%] w-[calc(100%-2rem)] max-w-lg bg-deepCosmos-800 rounded-xl shadow-xl p-6 z-[101] max-h-[90vh] overflow-y-auto">
            <Dialog.Title className="text-2xl font-bold text-prismWhite mb-4">
              Complete Your Qube
            </Dialog.Title>
            
            <Dialog.Description className="text-quantumGrey-300 mb-6">
              Fill in your details to get started with your custom Qube solution.
            </Dialog.Description>
            
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="text-sm font-medium text-quantumGrey-300 mb-1 block">
                  Name
                </label>
                <input
                  type="text"
                  required
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="w-full bg-deepCosmos-700 border border-deepCosmos-600 rounded-lg px-4 py-2 text-prismWhite focus:border-metaEmerald-500 transition-colors"
                  placeholder="Your name"
                />
              </div>
              
              <div>
                <label className="text-sm font-medium text-quantumGrey-300 mb-1 block">
                  Email
                </label>
                <input
                  type="email"
                  required
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  className="w-full bg-deepCosmos-700 border border-deepCosmos-600 rounded-lg px-4 py-2 text-prismWhite focus:border-metaEmerald-500 transition-colors"
                  placeholder="your@email.com"
                />
              </div>
              
              <div>
                <label className="text-sm font-medium text-quantumGrey-300 mb-1 block">
                  Country
                </label>
                <input
                  type="text"
                  required
                  value={formData.country}
                  onChange={(e) => setFormData({ ...formData, country: e.target.value })}
                  className="w-full bg-deepCosmos-700 border border-deepCosmos-600 rounded-lg px-4 py-2 text-prismWhite focus:border-metaEmerald-500 transition-colors"
                  placeholder="Your country"
                />
              </div>
              
              <div>
                <label className="text-sm font-medium text-quantumGrey-300 mb-1 block">
                  Project Description
                </label>
                <textarea
                  required
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  className="w-full bg-deepCosmos-700 border border-deepCosmos-600 rounded-lg px-4 py-2 text-prismWhite focus:border-metaEmerald-500 transition-colors"
                  placeholder="Tell us more about your project"
                  rows={4}
                />
              </div>
              
              <button
                type="submit"
                className="w-full bg-metaEmerald-500 text-deepCosmos-900 font-bold py-3 px-4 rounded-lg hover:bg-metaEmerald-400 transition-colors mt-6 relative overflow-hidden group"
              >
                <motion.div
                  className="absolute inset-0 bg-white opacity-0 group-hover:opacity-20 transition-opacity duration-300"
                />
                <span className="relative z-10">
                  {submitted ? 'Submitted!' : 'Submit'}
                </span>
              </button>
            </form>
            
            <Dialog.Close asChild>
              <button
                className="absolute top-4 right-4 text-quantumGrey-300 hover:text-prismWhite transition-colors"
                aria-label="Close"
              >
                <X size={20} />
              </button>
            </Dialog.Close>
          </Dialog.Content>
        </Dialog.Portal>
      </Dialog.Root>
    </section>
  );
};

export default BuildYourQube;