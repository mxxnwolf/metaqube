import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useAppStore } from '../../store/useAppStore';

const ToggleGroup: React.FC = () => {
  const { toggleOptions, updateToggleOption } = useAppStore();
  const [message, setMessage] = useState<string>('Pick any two');
  
  useEffect(() => {
    const fast = toggleOptions.find(o => o.id === 'fast')?.active || false;
    const cheap = toggleOptions.find(o => o.id === 'cheap')?.active || false;
    const good = toggleOptions.find(o => o.id === 'good')?.active || false;
    
    const activeCount = toggleOptions.filter(o => o.active).length;
    
    if (activeCount < 2) {
      setMessage('Pick any two');
    } else if (fast && cheap) {
      setMessage("You get what you get. 🤷‍♂️");
    } else if (cheap && good) {
      setMessage("It's gonna take time. ⏳");
    } else if (fast && good) {
      setMessage("The best choice of them all! 🌟");
    }
  }, [toggleOptions]);
  
  return (
    <div className="relative p-8 bg-deepCosmos-800/50 rounded-xl backdrop-blur-sm">
      <div className="flex flex-col items-center space-y-6">
        <h2 className="text-2xl font-bold text-prismWhite">Project Parameters</h2>
        
        <div className="flex flex-wrap justify-center gap-4">
          {toggleOptions.map((option) => (
            <motion.button
              key={option.id}
              onClick={() => updateToggleOption(option.id, !option.active)}
              className={`relative px-6 py-3 rounded-lg text-lg font-semibold transition-all overflow-hidden
                ${option.active 
                  ? 'bg-metaEmerald-500 text-deepCosmos-900 shadow-lg' 
                  : 'bg-deepCosmos-600 text-quantumGrey-300 hover:bg-deepCosmos-500'}`}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              {/* Glow effect */}
              {option.active && (
                <motion.div
                  className="absolute inset-0 bg-metaEmerald-500"
                  initial={{ opacity: 0 }}
                  animate={{ 
                    opacity: [0.2, 0.4, 0.2],
                    scale: [1, 1.2, 1]
                  }}
                  transition={{ duration: 2, repeat: Infinity }}
                />
              )}
              
              {/* Button content */}
              <span className="relative z-10">{option.label}</span>
              
              {/* Active indicator */}
              {option.active && (
                <motion.div
                  className="absolute right-2 top-1/2 -translate-y-1/2 w-2 h-2 bg-deepCosmos-900 rounded-full"
                  layoutId={`indicator-${option.id}`}
                />
              )}
            </motion.button>
          ))}
        </div>
        
        <AnimatePresence mode="wait">
          <motion.div
            key={message}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="text-center text-lg font-medium text-metaEmerald-400"
          >
            {message}
          </motion.div>
        </AnimatePresence>
      </div>
    </div>
  );
};

export default ToggleGroup;